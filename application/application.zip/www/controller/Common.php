<?php
namespace app\www\controller;

use app\common\controller\Base;

class Common extends Base {
	public function _initialize(){
        parent::_initialize();
    }
    
}